## Template for geospatial analysis

# Authors: Janek Bruker, Colin Walder

# The following template is intended to simplify the visualisation of geodata
# Included and prepared are: Municipalities, Productive Municipalities, Borders, Lakes and Rivers. 
# At the end, a toy example will help to understand how the shapefiles can be linked with survey geodata 
# Illustrated are 100 randomly selected power plants in Switzerland.

# Packages used

library(tidyverse)
library(raster)
library(sp)
library(sf)

# Municipalities Switzerland -------------------------------------------------------

municipality_sf <- read_sf("municipalities/swissBOUNDARIES3D_1_3_TLM_HOHEITSGEBIET.shp")

# only keep information on muni number
municipality_sf <- municipality_sf[,"BFS_NUMMER"]

# assing identifier
municipality_sf$ID <- 1:nrow(municipality_sf)

municipality_sf$srph_municipal <- municipality_sf$BFS_NUMMER
municipality_sf$BFS_NUMMER <- NULL
municipality_sf$ID <- NULL

plot(municipality_sf)

# Productive Municipalities/Cantons Switzerland ---------------------------

municipality_prod_sf <- read_sf("productive_municipalities/K4polg20180101vf_ch2007Poly.shp")

plot(municipality_prod_sf[,1])

canton_prod_sf <- read_sf("productive_cantons/K4kant19970101vf_ch2007Poly.shp")
canton_prod_sf <- canton_prod_sf[,"ID1"]

plot(canton_prod_sf)


# Borders Switzerland --------------------------------------------------

borders <- read_rds("gadm36_CHE_0_sp.rds")

# if not available locally:
# CHE <- getData('GADM', country='CHE', level=0)

# transform from sp to sf object and assign Swiss coordinate reference system

borders_sf <- borders %>% 
  st_as_sf() %>% 
  st_set_crs(4326) %>% 
  st_transform(2056)

# checking 
st_geometry(borders_sf)

plot(borders_sf)

rm(borders)

# Lakes Switzerland -------------------------------------------------------

lakes <- read_sf("lakes/g2s19.shp")

lakes_sf <- lakes[,2] %>% 
  st_transform(2056)

# cut to borders switzerland
lakes_sf <- st_intersection(lakes_sf, borders_sf)[,1]
rm(lakes)

plot(lakes_sf)


# Rivers Switzerland ------------------------------------------------------

rivers1 <- read_sf("rivers/k4flusyyyymmdd55_ch2007.shp")
rivers2 <- read_sf("rivers/k4flusyyyymmdd11_ch2007.shp")
rivers3 <- read_sf("rivers/k4flusyyyymmdd22_ch2007.shp")
rivers4 <- read_sf("rivers/k4flusyyyymmdd33_ch2007.shp")
rivers5 <- read_sf("rivers/k4flusyyyymmdd44_ch2007.shp")

rivers <- rbind(rivers1, rivers2, rivers3, rivers4, rivers5)[,1]

rm(rivers1); rm(rivers2); rm(rivers3); rm(rivers4); rm(rivers5); 

# cut to borders switzerland
rivers_sf <-st_transform(rivers, 2056) %>% 
  st_intersection(borders_sf)[,1]

rm(rivers)
plot(rivers_sf)


# Electricity plants Switzerland ------------------------------------------

# Source: https://opendata.swiss/en/dataset/elektrizitatsproduktionsanlagen

elec_plants <- read_csv("elektritaetswerke_ch/ElectricityProductionPlant.csv") %>% 
  drop_na() %>% 
  sample_n(100)  

elec_plants_sf <- elec_plants %>% 
  st_as_sf(coords=c("_x","_y"), crs=2056)


# Assemble everything -------------------------------------------------------------

ggplot() +
  geom_sf(data = borders_sf, fill = "darkgrey", color = "#D7CDCC") +
  geom_sf(data = canton_prod_sf, fill = "#D7CDCC", color = "grey") +
  #geom_sf(data = municipality_prod_sf, fill = "#D7CDCC", color = "grey") +
  geom_sf(data = rivers_sf, color = "#0081A7", alpha = 0.5) +
  geom_sf(data = lakes_sf, fill = "#0081A7", color = "#0081A7", alpha = 0.5) +
  geom_sf(data = elec_plants_sf, aes(size = TotalPower), color = "#D81159") +
  ggtitle("A random sample of 100 electricity plants") +
  hrbrthemes::theme_ipsum()
